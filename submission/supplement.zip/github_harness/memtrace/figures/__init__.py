"""Figure regeneration entrypoints for MEMTRACE."""

"""Module entrypoint for rebuilding paper figures from retained metrics."""

from scripts.make_paper_figures import main


if __name__ == "__main__":
    main()

try:
    import _bootstrap  # noqa: F401
except ModuleNotFoundError:
    pass

import argparse
import json
import os
from pathlib import Path

os.environ.setdefault("XDG_CACHE_HOME", str(Path(".cache").resolve()))
os.environ.setdefault("MPLCONFIGDIR", str(Path(".cache/matplotlib").resolve()))

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
from memtrace.eval.metrics import wilson_ci

mpl.rcParams["pdf.fonttype"] = 42
mpl.rcParams["ps.fonttype"] = 42


DEFAULT_METRICS_PATH = Path("data/results/metrics.json")
DEFAULT_CALIBRATION_METRICS_PATH = Path("data/calibration/oracle_memory/metrics.json")
DEFAULT_EPISODE_SCORES_PATH = Path("data/results/episode_scores.json")
DEFAULT_OUTPUT_DIR = Path("paper/manuscript/figures")

SYSTEMS = ("S0", "S1", "S2")
OVR_COLOR = "#b85c38"
SVR_COLOR = "#2f6f5e"


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate PDF figures for the MEMTRACE paper draft.")
    parser.add_argument("--metrics-path", type=Path, default=DEFAULT_METRICS_PATH)
    parser.add_argument("--calibration-metrics-path", type=Path, default=DEFAULT_CALIBRATION_METRICS_PATH)
    parser.add_argument("--episode-scores-path", type=Path, default=DEFAULT_EPISODE_SCORES_PATH)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    args = parser.parse_args()

    with args.metrics_path.open("r", encoding="utf-8") as handle:
        metrics = json.load(handle)
    calibration_metrics = None
    if args.calibration_metrics_path.exists():
        with args.calibration_metrics_path.open("r", encoding="utf-8") as handle:
            calibration_metrics = json.load(handle)
    with args.episode_scores_path.open("r", encoding="utf-8") as handle:
        episode_scores = json.load(handle)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    build_pipeline(args.output_dir / "figure1_pipeline.pdf")
    build_ovr_vs_svr(metrics, args.output_dir / "figure2_ovr_vs_svr.pdf", calibration_metrics)
    build_causal_chain_funnel(metrics, args.output_dir / "figure3_par_by_task_family.pdf")
    build_task_localization(episode_scores, args.output_dir / "figure4_one_shot_vs_stateful.pdf")
    build_violation_by_horizon(episode_scores, args.output_dir / "figure5_violation_by_horizon.pdf")

    print(f"paper_figures_dir={args.output_dir}")


def build_pipeline(output_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(10.8, 3.55))
    ax.set_axis_off()
    ax.text(0.05, 2.72, "Turn t: initial exposure", fontsize=11, fontweight="bold", va="center")
    ax.text(0.05, 1.32, "Turn t + $\\Delta$: delayed trigger", fontsize=11, fontweight="bold", va="center")

    initial = [
        (0.25, 1.9, "Poisoned\ncorpus"),
        (1.55, 1.9, "Initial\nretrieval"),
        (2.85, 1.9, "Memory\nwriter"),
        (4.15, 1.9, "Admission\nfilter"),
        (5.45, 1.9, "Persistent\nmemory"),
    ]
    trigger = [
        (0.9, 0.6, "Benign\ntrigger"),
        (2.2, 0.6, "Memory\nretrieval"),
        (3.5, 0.6, "Planner\nproposal"),
        (4.8, 0.6, "Policy\nchecker"),
        (6.1, 0.6, "Tool\nexecution"),
    ]
    for box in initial + trigger:
        _draw_box(ax, *box)
    for first, second in zip(initial, initial[1:]):
        _arrow(ax, first[0] + 0.9, first[1] + 0.22, second[0], second[1] + 0.22)
    for first, second in zip(trigger, trigger[1:]):
        _arrow(ax, first[0] + 0.9, first[1] + 0.22, second[0], second[1] + 0.22)

    ax.plot([5.9, 5.9, 2.65], [1.9, 1.3, 1.3], color="#2f6f5e", linewidth=1.0)
    _arrow(ax, 2.65, 1.3, 2.65, 1.05, color="#2f6f5e")
    ax.text(2.65, 0.28, "PRR", ha="center", va="center", fontsize=9, color="#2f6f5e", fontweight="bold")

    _arrow(ax, 1.9, 1.86, 3.74, 0.98, connectionstyle="arc3,rad=-0.28", color="#b85c38")
    ax.text(2.85, 1.37, "current-turn OVR", ha="center", va="center", fontsize=9, color="#b85c38", fontweight="bold")

    ax.text(4.55, 2.42, "PAR", ha="center", va="center", fontsize=9, color="#356d9a", fontweight="bold")
    ax.text(4.18, 0.28, "UPR", ha="center", va="center", fontsize=9, color="#356d9a", fontweight="bold")
    ax.text(5.2, 0.28, "blocked", ha="center", va="center", fontsize=9, color="#356d9a", fontweight="bold")
    ax.text(6.55, 0.28, "SVR", ha="center", va="center", fontsize=9, color="#356d9a", fontweight="bold")
    _arrow(ax, 3.95, 0.56, 3.95, 0.18, color="#777777")
    ax.text(3.95, 0.05, "EFR", ha="center", va="center", fontsize=9, color="#777777", fontweight="bold")

    checkpoints = [
        (1.55, 2.58, "1 poison retrieved"),
        (2.85, 2.58, "2 candidate emitted"),
        (4.15, 2.58, "3 poison admitted"),
        (2.2, 1.17, "4 memory retrieved"),
        (3.5, 1.17, "5 unsafe proposal"),
        (4.8, 1.17, "6 checker block"),
        (6.1, 1.17, "7 unsafe execution"),
    ]
    for x, y, label in checkpoints:
        ax.text(x + 0.45, y, label, ha="center", va="center", fontsize=7.3, color="#555555")

    ax.set_xlim(0.0, 7.25)
    ax.set_ylim(-0.1, 3.05)
    _save_pdf(fig, output_path)


def build_causal_chain_funnel(metrics: dict, output_path: Path) -> None:
    actor_model = next(iter(metrics["by_configuration"]))
    rows = metrics["by_configuration"][actor_model]
    s1_counts = rows["S1"]["causal_chain_counts"]
    stateful = s1_counts["stateful_attacks"]
    admitted = s1_counts["poison_admitted"]
    retrieved = s1_counts["admitted_poison_retrieved_at_trigger"]
    failures = s1_counts["execution_failure"]
    proposal = s1_counts["unsafe_proposal_before_checker"]
    executed = s1_counts["unsafe_executed"]
    stages = [
        ("Stateful\nattacks", str(stateful), "#777777"),
        ("Poison\nadmitted", f"{admitted}/{stateful}", "#2f6f5e"),
        ("Retrieved\nat trigger", f"{retrieved}/{admitted}", "#2f6f5e"),
        ("Unsafe\nproposals", f"{proposal}/{stateful}", "#b85c38"),
        ("Unsafe\nexecutions", f"{executed}/{stateful}", "#777777"),
    ]

    fig, ax = plt.subplots(figsize=(6.9, 2.95))
    ax.set_axis_off()
    ax.text(0.02, 0.94, "Where the S1 delayed chain stops", transform=ax.transAxes, fontsize=10, fontweight="bold")
    ax.text(
        0.02,
        0.84,
        "72 stateful attacks -> 6 admitted -> 6 retrieved -> 0 unsafe proposals -> 0 executions",
        transform=ax.transAxes,
        fontsize=8,
        color="#555555",
    )
    x0 = 0.03
    y0 = 0.45
    box_w = 0.15
    box_h = 0.20
    gap = 0.045
    for index, (label, value, color) in enumerate(stages):
        x = x0 + index * (box_w + gap)
        face_alpha = 0.18 if value.startswith("0/") else 0.82
        rect = FancyBboxPatch(
            (x, y0),
            box_w,
            box_h,
            boxstyle="round,pad=0.01,rounding_size=0.015",
            facecolor=color,
            alpha=face_alpha,
            edgecolor=color,
            linewidth=1.0,
            transform=ax.transAxes,
        )
        ax.add_patch(rect)
        ax.text(x + box_w / 2, y0 + 0.132, value, transform=ax.transAxes, ha="center", va="center", fontsize=8.2, fontweight="bold", linespacing=0.9)
        ax.text(x + box_w / 2, y0 + 0.055, label, transform=ax.transAxes, ha="center", va="center", fontsize=7.7)
        if index < len(stages) - 1:
            ax.annotate(
                "",
                xy=(x + box_w + gap * 0.78, y0 + box_h / 2),
                xytext=(x + box_w + gap * 0.18, y0 + box_h / 2),
                xycoords=ax.transAxes,
                textcoords=ax.transAxes,
                arrowprops=dict(arrowstyle="-|>", color="#555555", linewidth=0.9),
            )
    ax.text(
        0.02,
        0.20,
        "S0/S2 do not persist poisoned memories in the main stateful packet.",
        transform=ax.transAxes,
        fontsize=8,
        color="#555555",
    )
    ax.text(
        0.02,
        0.10,
        f"Stateful execution-format failures: {failures} per system, counted outside unsafe-action rates.",
        transform=ax.transAxes,
        fontsize=8,
        color="#555555",
    )
    _save_pdf(fig, output_path)


def build_ovr_vs_svr(metrics: dict, output_path: Path, calibration_metrics: dict | None = None) -> None:
    actor_model = next(iter(metrics["by_configuration"]))
    rows = metrics["by_configuration"][actor_model]
    calibration = _calibration_row(calibration_metrics)
    fig, axes = plt.subplots(1, 3, figsize=(7.4, 2.55), gridspec_kw={"wspace": 0.42})
    panel_specs = [
        (
            "A. One-shot unsafe",
            [
                (system, _count_text(rows[system]["rate_counts"]["one_shot_unsafe"]))
                for system in SYSTEMS
            ],
            OVR_COLOR,
        ),
        (
            "B. Memory path",
            [
                ("S0", "no persistence"),
                (
                    "S1",
                    _count_text(rows["S1"]["rate_counts"]["poison_admitted"], " admitted")
                    + "\n"
                    + _count_text(rows["S1"]["rate_counts"]["admitted_memory_retrieved_at_trigger"], " retrieved"),
                ),
                ("S2", _count_text(rows["S2"]["rate_counts"]["poison_admitted"], " admitted")),
            ],
            "#356d9a",
        ),
        (
            "C. Delayed unsafe",
            [
                ("S0", _count_text(rows["S0"]["rate_counts"]["stateful_unsafe"])),
                ("S1", _count_text(rows["S1"]["rate_counts"]["stateful_unsafe"])),
                ("S2", _count_text(rows["S2"]["rate_counts"]["stateful_unsafe"])),
                ("Cal.", _count_text([calibration["unsafe_executed"], calibration["episodes"]]) if calibration else "not run"),
            ],
            SVR_COLOR,
        ),
    ]
    for ax, (title, rows_to_draw, color) in zip(axes, panel_specs):
        _draw_count_panel(ax, title, rows_to_draw, color)
    fig.text(
        0.02,
        0.03,
        "Counts are exact. Calibration is excluded from main S0/S1/S2 rates.",
        fontsize=7.5,
        color="#555555",
    )
    _save_pdf(fig, output_path)


def build_task_localization(episode_scores: list[dict], output_path: Path) -> None:
    rows = _s1_task_stage_counts(episode_scores)
    stages = [
        ("candidate", "writer_candidate_emitted"),
        ("admitted", "poison_admitted"),
        ("retrieved", "admitted_retrieved"),
        ("unsafe\nprop.", "unsafe_proposal"),
        ("unsafe\nexec.", "unsafe_executed"),
        ("exec\nfail", "execution_failure"),
    ]
    fig, ax = plt.subplots(figsize=(7.25, 4.85))
    ax.set_axis_off()
    ax.text(0.02, 0.97, "Task-by-stage S1 stateful signal", transform=ax.transAxes, fontsize=10.5, fontweight="bold")
    ax.text(0.02, 0.925, "counts over six stateful attacks per task; zero stages remain explicit", transform=ax.transAxes, fontsize=8, color="#555555")
    x0 = 0.245
    y0 = 0.805
    cell_w = 0.108
    cell_h = 0.043
    row_gap = 0.015
    col_gap = 0.014
    for col, (label, _) in enumerate(stages):
        x = x0 + col * (cell_w + col_gap)
        ax.text(
            x + cell_w / 2,
            y0 + cell_h + 0.028,
            label,
            transform=ax.transAxes,
            ha="center",
            va="bottom",
            fontsize=7.2,
            linespacing=0.9,
        )
    for row_index, (task_id, counts) in enumerate(rows):
        y = y0 - row_index * (cell_h + row_gap)
        ax.text(0.02, y + cell_h / 2, _short_task_label(task_id), transform=ax.transAxes, va="center", fontsize=8.0)
        denominator = counts["denominator"]
        for col, (_, key) in enumerate(stages):
            count = counts[key]
            x = x0 + col * (cell_w + col_gap)
            fill = "#2f6f5e" if key in {"writer_candidate_emitted", "poison_admitted", "admitted_retrieved"} else "#b85c38"
            if key == "execution_failure":
                fill = "#8a8a8a"
            rect = FancyBboxPatch(
                (x, y),
                cell_w,
                cell_h,
                boxstyle="round,pad=0.004,rounding_size=0.006",
                facecolor=fill,
                alpha=0.18 + 0.72 * (count / max(denominator, 1)),
                edgecolor="#c7c7c7",
                linewidth=0.55,
                transform=ax.transAxes,
            )
            ax.add_patch(rect)
            ax.text(
                x + cell_w / 2,
                y + cell_h / 2,
                f"{count}/{denominator}",
                transform=ax.transAxes,
                ha="center",
                va="center",
                fontsize=6.9,
                fontweight="bold" if count else "normal",
            )
    ax.text(0.02, 0.055, "Admissions localize to budget-limit-rule and calendar-attendee; unsafe proposal/execution remains 0/6 for every task.", transform=ax.transAxes, fontsize=7.8, color="#555555")
    _save_pdf(fig, output_path)


def build_violation_by_horizon(episode_scores: list[dict], output_path: Path) -> None:
    rows = _s1_horizon_diagnostics(episode_scores)
    horizons = (1, 3, 7)
    stages = [
        ("Poison admitted", "poison_admitted", "#d9ebe5"),
        ("Admitted retrieved", "admitted_retrieved", "#d9ebe5"),
        ("Execution failure", "execution_failure", "#ededed"),
    ]

    fig, ax = plt.subplots(figsize=(6.4, 2.75))
    ax.set_axis_off()
    ax.text(0.02, 0.95, "S1 stateful chain by horizon", transform=ax.transAxes, fontsize=10, fontweight="bold")
    ax.text(
        0.02,
        0.88,
        "counts over 24 stateful episodes per horizon; unsafe proposal/execution is summarized once",
        transform=ax.transAxes,
        fontsize=8,
        color="#555555",
    )
    x0 = 0.36
    y0 = 0.66
    cell_w = 0.18
    cell_h = 0.09
    row_gap = 0.035
    col_gap = 0.04
    for col, horizon in enumerate(horizons):
        x = x0 + col * (cell_w + col_gap)
        ax.text(
            x + cell_w / 2,
            y0 + cell_h + 0.035,
            f"$\\Delta={horizon}$",
            transform=ax.transAxes,
            ha="center",
            fontsize=8.5,
        )
    for row_index, (label, key, fill) in enumerate(stages):
        y = y0 - row_index * (cell_h + row_gap)
        ax.text(0.02, y + cell_h / 2, label, transform=ax.transAxes, va="center", fontsize=8.5)
        for col, horizon in enumerate(horizons):
            item = rows[horizon]
            count = item[key]
            denominator = item["denominator"]
            x = x0 + col * (cell_w + col_gap)
            rect = FancyBboxPatch(
                (x, y),
                cell_w,
                cell_h,
                boxstyle="round,pad=0.005,rounding_size=0.008",
                facecolor=fill,
                alpha=1.0 if count else 0.35,
                edgecolor="#2f6f5e" if key in {"poison_admitted", "admitted_retrieved"} and count else "#b8b8b8",
                linewidth=0.8,
                transform=ax.transAxes,
            )
            ax.add_patch(rect)
            ax.text(
                x + cell_w / 2,
                y + cell_h / 2,
                f"{count}/{denominator}",
                transform=ax.transAxes,
                ha="center",
                va="center",
                fontsize=8.5,
                fontweight="bold",
            )
    band_y = 0.18
    rect = FancyBboxPatch(
        (0.27, band_y),
        0.68,
        0.105,
        boxstyle="round,pad=0.006,rounding_size=0.01",
        facecolor="#fff4ed",
        alpha=0.55,
        edgecolor="#b85c38",
        linewidth=0.8,
        transform=ax.transAxes,
    )
    ax.add_patch(rect)
    ax.text(
        0.61,
        band_y + 0.052,
        "Unsafe endpoint: not observed at any horizon",
        transform=ax.transAxes,
        ha="center",
        va="center",
        fontsize=8.1,
        fontweight="bold",
    )
    ax.text(
        0.02,
        0.05,
        "Execution failures are counted separately and are not asserted to be the same episodes as admitted-memory cases.",
        transform=ax.transAxes,
        fontsize=8,
        color="#555555",
    )
    _save_pdf(fig, output_path)


def _s1_horizon_diagnostics(episode_scores: list[dict]) -> dict[int, dict[str, int]]:
    rows: dict[int, dict[str, int]] = {}
    for horizon in (1, 3, 7):
        items = [
            item
            for item in episode_scores
            if item["system"] == "S1"
            and item["episode_kind"] == "stateful_attack"
            and item["horizon"] == horizon
        ]
        rows[horizon] = {
            "denominator": len(items),
            "poison_admitted": sum(1 for item in items if item.get("poison_admission_flag") is True),
            "admitted_retrieved": sum(1 for item in items if item.get("admitted_memory_retrieved_at_trigger")),
            "unsafe_proposal": sum(1 for item in items if item.get("unsafe_tool_call_proposed_before_checker")),
            "unsafe_executed": sum(1 for item in items if item.get("unsafe_tool_call_executed")),
            "execution_failure": sum(1 for item in items if item.get("execution_failure")),
        }
    return rows


def _s1_task_stage_counts(episode_scores: list[dict]) -> list[tuple[str, dict[str, int]]]:
    rows = []
    for task_id in sorted({item["task_id"] for item in episode_scores if item["episode_kind"] == "stateful_attack"}):
        items = [
            item
            for item in episode_scores
            if item["system"] == "S1"
            and item["episode_kind"] == "stateful_attack"
            and item["task_id"] == task_id
        ]
        rows.append(
            (
                task_id,
                {
                    "denominator": len(items),
                    "writer_candidate_emitted": sum(1 for item in items if item.get("writer_candidate_emitted")),
                    "poison_admitted": sum(1 for item in items if item.get("poison_admission_flag") is True),
                    "admitted_retrieved": sum(1 for item in items if item.get("admitted_memory_retrieved_at_trigger")),
                    "unsafe_proposal": sum(1 for item in items if item.get("unsafe_tool_call_proposed_before_checker")),
                    "unsafe_executed": sum(1 for item in items if item.get("unsafe_tool_call_executed")),
                    "execution_failure": sum(1 for item in items if item.get("execution_failure")),
                },
            )
        )
    return rows


def _calibration_row(calibration_metrics: dict | None) -> dict | None:
    if not calibration_metrics:
        return None
    return calibration_metrics.get("calibration_by_condition", {}).get("S1-ORACLE-RETRIEVED-MEMORY")


def _count_text(count_pair: list[int], suffix: str = "") -> str:
    numerator, denominator = count_pair
    return f"{numerator}/{denominator}{suffix}"


def _draw_count_panel(ax, title: str, rows: list[tuple[str, str]], color: str) -> None:
    ax.set_axis_off()
    ax.text(0.0, 0.98, title, transform=ax.transAxes, fontsize=8.8, fontweight="bold", va="top")
    y_positions = [0.72, 0.52, 0.32, 0.12]
    for y, (label, text) in zip(y_positions, rows):
        ax.text(0.02, y, label, transform=ax.transAxes, fontsize=8.7, va="center")
        fill = "#eeeeee" if "no persistence" in text or "not run" in text else color
        alpha = 0.88 if fill == "#eeeeee" else 0.24
        if text.startswith(("3/", "6/", "7/")):
            alpha = 0.55
        rect = FancyBboxPatch(
            (0.30, y - 0.065),
            0.62,
            0.12 if "\n" not in text else 0.16,
            boxstyle="round,pad=0.006,rounding_size=0.01",
            facecolor=fill,
            alpha=alpha,
            edgecolor=color if fill != "#eeeeee" else "#b0b0b0",
            linewidth=0.8,
            transform=ax.transAxes,
        )
        ax.add_patch(rect)
        ax.text(0.61, y - 0.005, text, transform=ax.transAxes, ha="center", va="center", fontsize=8.5, fontweight="bold", linespacing=1.0)


def _ci_from_rate_counts(row: dict, count_key: str) -> list[float]:
    successes, total = row["rate_counts"][count_key]
    return wilson_ci(successes, total)


def _annotate_bar(ax, patch, label: str, y_offset: float = 0.018, top: float | None = None) -> None:
    height = patch.get_height()
    ax.text(
        patch.get_x() + patch.get_width() / 2,
        (height if top is None else max(height, top)) + y_offset,
        label,
        ha="center",
        va="bottom",
        fontsize=8,
        fontweight="bold",
    )


def _draw_box(ax, x: float, y: float, label: str) -> None:
    width = 0.9
    height = 0.44
    box = FancyBboxPatch(
        (x, y),
        width,
        height,
        boxstyle="round,pad=0.03,rounding_size=0.05",
        facecolor="#faf8f3",
        edgecolor="#2b2b2b",
        linewidth=1.0,
    )
    ax.add_patch(box)
    ax.text(x + width / 2, y + height / 2, label, ha="center", va="center", fontsize=8.5)


def _arrow(
    ax,
    x_start: float,
    y_start: float,
    x_end: float,
    y_end: float,
    *,
    connectionstyle: str = "arc3,rad=0.0",
    color: str = "#1f1f1f",
) -> None:
    arrow = FancyArrowPatch(
        (x_start, y_start),
        (x_end, y_end),
        arrowstyle="-|>",
        mutation_scale=10,
        linewidth=1.0,
        color=color,
        connectionstyle=connectionstyle,
    )
    ax.add_patch(arrow)


def _style_rate_axis(ax, yticks=(0.0, 0.5, 1.0)) -> None:
    ax.set_yticks(list(yticks))
    ax.grid(axis="y", color="#dddddd", linewidth=0.7)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def _short_task_label(task_id: str) -> str:
    return {
        "budget-limit-rule": "budget limit",
        "calendar-attendee": "calendar attendee",
        "approval-limit-rule": "approval limit",
        "access-control-rule": "access control",
        "data-sharing-rule": "data sharing",
        "escalation-rule": "escalation",
        "permission-scope-rule": "permission scope",
        "email-recipient": "email recipient",
        "meeting-time": "meeting time",
        "file-destination": "file destination",
        "expense-code": "expense code",
        "calendar-location": "calendar location",
    }.get(task_id, task_id)


def _save_pdf(fig, output_path: Path) -> None:
    fig.savefig(output_path, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()

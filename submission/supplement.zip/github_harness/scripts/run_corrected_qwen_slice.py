try:
    import _bootstrap  # noqa: F401
except ModuleNotFoundError:
    pass

import argparse
import os
import subprocess
import sys
from pathlib import Path


ACTOR_MODEL = "mlx-community/Qwen2.5-7B-Instruct-4bit"
TASK_IDS = ("access-control-rule", "budget-limit-rule", "data-sharing-rule")
SYSTEMS = ("S0", "S1", "S2")
DEFAULT_SLICE_DIR = Path("data/pilot/qwen25_corrected_affected_slice")
DEFAULT_MERGED_DIR = Path("data/pilot/qwen25_corrected_merged")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Run, validate, audit, and conditionally promote the corrected Qwen slice.")
    parser.add_argument("--slice-dir", type=Path, default=DEFAULT_SLICE_DIR)
    parser.add_argument("--merged-dir", type=Path, default=DEFAULT_MERGED_DIR)
    parser.add_argument("--base-summary", type=Path, default=Path("data/results/run_summary.json"))
    parser.add_argument("--expected-episodes", type=int, default=324)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--skip-post-promotion", action="store_true")
    args = parser.parse_args(argv)

    raise SystemExit(
        run_corrected_qwen_slice(
            slice_dir=args.slice_dir,
            merged_dir=args.merged_dir,
            base_summary=args.base_summary,
            expected_episodes=args.expected_episodes,
            dry_run=args.dry_run,
            force=args.force,
            skip_post_promotion=args.skip_post_promotion,
        )
    )


def run_corrected_qwen_slice(
    *,
    slice_dir: Path,
    merged_dir: Path,
    base_summary: Path,
    expected_episodes: int,
    dry_run: bool = False,
    force: bool = False,
    skip_post_promotion: bool = False,
    runner=subprocess.run,
    python: str = sys.executable,
) -> int:
    dry_run_cmd = _run_pilot_cmd(python, slice_dir, dry_run=True, force=False)
    code = _run_command(dry_run_cmd, runner=runner)
    if code != 0 or dry_run:
        return code

    env = os.environ.copy()
    env["MEMTRACE_MEMORY_WRITER_BACKEND"] = "mlx"
    env["MEMTRACE_PLANNER_BACKEND"] = "mlx"
    run_cmd = _run_pilot_cmd(python, slice_dir, dry_run=False, force=force)
    code = _run_command(run_cmd, runner=runner, env=env)
    if code != 0:
        print("corrected slice run failed; no promotion attempted")
        return code

    commands = [
        [
            python,
            "scripts/merge_repair_runs.py",
            "--base-summary",
            str(base_summary),
            "--repair-summary",
            str(slice_dir / "run_summary.json"),
            "--out-dir",
            str(merged_dir),
            "--actor-model",
            ACTOR_MODEL,
        ],
        [python, "scripts/validate_run.py", "--metrics-path", str(merged_dir / "metrics.json")],
        [
            python,
            "scripts/make_audit.py",
            "--episode-scores",
            str(merged_dir / "episode_scores.json"),
            "--sample-path",
            str(merged_dir / "audit_sample.json"),
            "--template-path",
            str(merged_dir / "audit_template.jsonl"),
            "--report-json-path",
            str(merged_dir / "audit_report.json"),
            "--report-md-path",
            str(merged_dir / "audit_report.md"),
        ],
        [
            python,
            "scripts/make_audit_review.py",
            "--audit-template",
            str(merged_dir / "audit_template.jsonl"),
            "--episode-scores",
            str(merged_dir / "episode_scores.json"),
            "--output",
            str(merged_dir / "audit_review.md"),
        ],
        [
            python,
            "scripts/promote_results.py",
            "--source-dir",
            str(merged_dir),
            "--expected-episodes",
            str(expected_episodes),
            "--audit-template-path",
            str(merged_dir / "audit_template.jsonl"),
            "--audit-report-path",
            str(merged_dir / "audit_report.json"),
        ],
    ]
    for command in commands:
        code = _run_command(command, runner=runner)
        if code != 0:
            print("promotion pipeline stopped before publishing paper-facing results")
            return code

    if skip_post_promotion:
        return 0
    for command in _post_promotion_commands(python):
        code = _run_command(command, runner=runner)
        if code != 0:
            return code
    return 0


def _run_pilot_cmd(python: str, out_dir: Path, *, dry_run: bool, force: bool) -> list[str]:
    command = [
        python,
        "scripts/run_pilot.py",
        "--actor-model",
        ACTOR_MODEL,
        "--out-dir",
        str(out_dir),
    ]
    for task_id in TASK_IDS:
        command.extend(["--task-id", task_id])
    for system in SYSTEMS:
        command.extend(["--system", system])
    if dry_run:
        command.append("--dry-run")
    if force:
        command.append("--force")
    return command


def _post_promotion_commands(python: str) -> list[list[str]]:
    return [
        [python, "scripts/make_paper_tables.py"],
        [python, "scripts/make_paper_figures.py"],
        [python, "scripts/make_paper_brief.py"],
        [python, "scripts/check_claim_evidence.py"],
        [python, "scripts/check_neurips_readiness.py"],
        [python, "scripts/export_release.py"],
    ]


def _run_command(command: list[str], *, runner, env: dict[str, str] | None = None) -> int:
    print("+ " + " ".join(command))
    completed = runner(command, env=env)
    return int(completed.returncode)


if __name__ == "__main__":
    main(sys.argv[1:])

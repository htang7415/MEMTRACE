import json
from pathlib import Path

from scripts.check_neurips_readiness import collect_readiness_checks, render_readiness_report


def test_collect_readiness_checks_reports_current_blockers(tmp_path: Path) -> None:
    metrics_path = tmp_path / "metrics.json"
    metrics_path.write_text(
        json.dumps(
            {
                "by_configuration": {
                    "model-a": {
                        "S0": _metric_row(),
                        "S1": _metric_row(),
                        "S2": _metric_row(),
                    }
                },
                "pilot_validation_by_configuration": {
                    "model-a": {
                        "S0": {"official_pilot_valid": True},
                        "S1": {"official_pilot_valid": True},
                        "S2": {"official_pilot_valid": True},
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    run_summary_path = tmp_path / "run_summary.json"
    run_summary_path.write_text(json.dumps([{"episode_id": "ep1"}]), encoding="utf-8")
    audit_template_path = tmp_path / "audit_template.jsonl"
    audit_template_path.write_text(json.dumps({"episode_id": "ep1", "human_label": None}) + "\n", encoding="utf-8")
    audit_report_path = tmp_path / "audit_report.json"
    audit_report_path.write_text(json.dumps({"n": 1, "agreements": 1, "agreement_rate": 1.0}), encoding="utf-8")

    paper_dir = tmp_path / "paper"
    (paper_dir / "tables").mkdir(parents=True)
    (paper_dir / "figures").mkdir()
    for path in (
        paper_dir / "main.tex",
        paper_dir / "main.pdf",
        paper_dir / "tables" / "main_results.tex",
        paper_dir / "tables" / "mechanism_counts.tex",
        paper_dir / "tables" / "causal_chain_counts.tex",
        paper_dir / "tables" / "confidence_intervals.tex",
        paper_dir / "tables" / "failure_attribution.tex",
        paper_dir / "tables" / "task_level_signal.tex",
        paper_dir / "tables" / "validity_gates.tex",
        paper_dir / "figures" / "figure1_pipeline.pdf",
        paper_dir / "figures" / "figure2_ovr_vs_svr.pdf",
        paper_dir / "figures" / "figure3_par_by_task_family.pdf",
        paper_dir / "references.bib",
    ):
        path.write_text("x", encoding="utf-8")
    (paper_dir / "main.tex").write_text(
        "Across the current 1-episode trace set, results show OVR 0.000--0.000, "
        "SVR 0.000--0.000, and EFR 0.000--0.000 with 1/1 agreement. "
        "S1 has zero admit-and-violate cases. S2 has zero poison admissions.",
        encoding="utf-8",
    )
    (paper_dir / "checklist.tex").write_text("\\answerTODO{}\\justificationTODO{}", encoding="utf-8")

    release_dir = tmp_path / "release"
    (release_dir / "results").mkdir(parents=True)
    (release_dir / "traces").mkdir()
    (release_dir / "manifest.json").write_text("{}", encoding="utf-8")
    (release_dir / "results" / "run_summary.json").write_text(json.dumps([{"episode_id": "ep1"}]), encoding="utf-8")
    (release_dir / "traces" / "trace.jsonl").write_text("{}\n", encoding="utf-8")

    checks = collect_readiness_checks(
        metrics_path=metrics_path,
        run_summary_path=run_summary_path,
        audit_template_path=audit_template_path,
        audit_report_path=audit_report_path,
        release_dir=release_dir,
        paper_dir=paper_dir,
        expected_episodes=1,
    )

    statuses = {check.name: check.status for check in checks}
    assert statuses["pilot validity"] == "PASS"
    assert statuses["claim discipline"] == "PASS"
    assert statuses["claim evidence"] == "PASS"
    assert statuses["included episode count"] == "PASS"
    assert statuses["paper artifacts"] == "PASS"
    assert statuses["human audit"] == "FAIL"
    assert statuses["official NeurIPS style"] == "FAIL"
    assert statuses["official checklist"] == "FAIL"
    assert statuses["references"] == "FAIL"


def test_render_readiness_report_lists_blockers() -> None:
    report = render_readiness_report(
        [
            _check("pilot validity", "PASS", "ok"),
            _check("references", "FAIL", "0 bibliography entries"),
        ]
    )

    assert "overall: BLOCKED" in report
    assert "- references: 0 bibliography entries" in report


def test_claim_discipline_blocks_pilot_invalid_final_framing(tmp_path: Path) -> None:
    metrics_path = tmp_path / "metrics.json"
    metrics_path.write_text(
        json.dumps(
            {
                "pilot_validation_by_configuration": {
                    "model-a": {
                        "S0": {"official_pilot_valid": False},
                        "S1": {"official_pilot_valid": True},
                        "S2": {"official_pilot_valid": True},
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    run_summary_path = tmp_path / "run_summary.json"
    run_summary_path.write_text("[]", encoding="utf-8")
    audit_template_path = tmp_path / "audit_template.jsonl"
    audit_template_path.write_text("", encoding="utf-8")
    audit_report_path = tmp_path / "audit_report.json"
    audit_report_path.write_text(json.dumps({"agreement_rate": 1.0}), encoding="utf-8")
    paper_dir = tmp_path / "paper"
    paper_dir.mkdir()
    (paper_dir / "main.tex").write_text("These are final comparative results.", encoding="utf-8")

    checks = collect_readiness_checks(
        metrics_path=metrics_path,
        run_summary_path=run_summary_path,
        audit_template_path=audit_template_path,
        audit_report_path=audit_report_path,
        release_dir=tmp_path / "release",
        paper_dir=paper_dir,
        expected_episodes=0,
    )

    statuses = {check.name: check.status for check in checks}
    assert statuses["claim discipline"] == "FAIL"


def _metric_row() -> dict:
    return {
        "OVR": 0.0,
        "SVR": 0.0,
        "planner_structured_output_rate": 1.0,
        "required_tool_call_rate": 1.0,
        "execution_failure_rate": 0.0,
        "writer_structured_turn_rate": 1.0,
        "writer_valid_memory_type_rate": 1.0,
        "PAR": 0.0,
        "mechanism_counts": {
            "a_admission_and_violation": 0,
            "b_admission_and_no_violation": 0,
        },
    }


def _check(name: str, status: str, detail: str):
    from scripts.check_neurips_readiness import ReadinessCheck

    return ReadinessCheck(name=name, status=status, detail=detail)

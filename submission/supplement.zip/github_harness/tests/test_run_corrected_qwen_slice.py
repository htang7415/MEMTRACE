import subprocess
from pathlib import Path

from scripts.run_corrected_qwen_slice import run_corrected_qwen_slice


def test_corrected_slice_dry_run_only_runs_inventory() -> None:
    calls = []

    def runner(command, env=None):
        calls.append((command, env))
        return subprocess.CompletedProcess(command, 0)

    code = run_corrected_qwen_slice(
        slice_dir=Path("slice"),
        merged_dir=Path("merged"),
        base_summary=Path("base.json"),
        expected_episodes=324,
        dry_run=True,
        runner=runner,
        python="python",
    )

    assert code == 0
    assert len(calls) == 1
    assert "--dry-run" in calls[0][0]


def test_corrected_slice_stops_before_promotion_when_validation_fails() -> None:
    calls = []

    def runner(command, env=None):
        calls.append(command)
        if _contains_script(command, "validate_run.py"):
            return subprocess.CompletedProcess(command, 1)
        return subprocess.CompletedProcess(command, 0)

    code = run_corrected_qwen_slice(
        slice_dir=Path("slice"),
        merged_dir=Path("merged"),
        base_summary=Path("base.json"),
        expected_episodes=324,
        force=True,
        runner=runner,
        python="python",
    )

    assert code == 1
    assert any(_contains_script(command, "validate_run.py") for command in calls)
    assert not any(_contains_script(command, "promote_results.py") for command in calls)


def test_corrected_slice_promotes_after_validation_and_audit_pass() -> None:
    calls = []

    def runner(command, env=None):
        calls.append((command, env))
        return subprocess.CompletedProcess(command, 0)

    code = run_corrected_qwen_slice(
        slice_dir=Path("slice"),
        merged_dir=Path("merged"),
        base_summary=Path("base.json"),
        expected_episodes=324,
        force=True,
        skip_post_promotion=True,
        runner=runner,
        python="python",
    )

    assert code == 0
    commands = [call[0] for call in calls]
    assert any(_contains_script(command, "run_pilot.py") and "--force" in command for command in commands)
    assert any(_contains_script(command, "make_audit.py") for command in commands)
    assert any(_contains_script(command, "promote_results.py") for command in commands)
    run_call = next(call for call in calls if _contains_script(call[0], "run_pilot.py") and "--force" in call[0])
    assert run_call[1]["MEMTRACE_MEMORY_WRITER_BACKEND"] == "mlx"
    assert run_call[1]["MEMTRACE_PLANNER_BACKEND"] == "mlx"


def _contains_script(command: list[str], script_name: str) -> bool:
    return any(part.endswith(script_name) for part in command)

# NeurIPS Paper Brief

## Claim To Lead With

MEMTRACE is a validity-first benchmark for memory-enabled agents. The promoted Qwen2.5-7B trace set now passes pilot validity: audit-calibrated results show immediate one-shot risk, no observed stateful unsafe executions in this pilot, and a poisoned-memory admission surface that S2 blocks.

## Do Not Claim

- Do not claim delayed exploitation in the promoted rows: stateful unsafe execution is not observed.
- Do not claim poisoned-memory admission implies downstream violation: admit-and-violate is not observed.
- Do not average in pilot-invalid or incomplete Llama runs.
- Do not treat one-shot `OVR` as delayed memory exploitation.

## Current Audit-Calibrated Results

| System | Clean success | One-shot unsafe | Memory-path signal | Delayed outcome | Exec failure |
| --- | ---: | ---: | --- | --- | ---: |
| S0 | 10/12 = 0.833 | 7/24 = 0.292 | not persisted | no persisted memory path | 8/108 = 0.074 |
| S1 | 10/12 = 0.833 | 6/24 = 0.250 | 6/72 admitted; 6/6 retrieved | retrieved poison not adopted | 8/108 = 0.074 |
| S2 | 10/12 = 0.833 | 6/24 = 0.250 | poisoned writes blocked | admission blocked before trigger | 8/108 = 0.074 |

## Abstract Draft

Memory-enabled agents can preserve the effects of untrusted retrieved content after that content leaves the active context, but standard one-shot safety tests often conflate immediate retrieval effects, delayed memory effects, and execution-format failure. We introduce MEMTRACE, a compact benchmark and protocol that separates these mechanisms under fixed retrieval, fixed tasks, and deterministic tool execution. Across the promoted 324-episode Qwen2.5-7B trace set, audit-calibrated results find immediate one-shot violations (OVR 0.250--0.292), no observed stateful unsafe executions (SVR 0.000--0.000), and low execution-failure rates (EFR 0.074--0.074). The human audit is reconciled with the automated scorer, and S1 has 6 admit-and-safe cases while S2 has zero poison admissions. MEMTRACE therefore supports a narrow, pilot-valid claim: it separates immediate retrieval-context risk from persistent-memory admission and from delayed policy violation.

## Paper Structure

1. Motivation: memory changes the safety surface because retrieved content can be written and later reused.
2. Threat model: corpus poisoning through retrieval into the memory writer; attacker cannot edit memory directly.
3. Benchmark: 12 tasks, two task families, two payload types, S0/S1/S2, fixed retrieval and deterministic tools.
4. Metrics: separate OVR, SVR, PAR/PAR-exec, execution failure, and mechanism counts.
5. Results: promoted pilot-valid rows, nonzero one-shot risk, no observed stateful unsafe execution, S1 admission signal.
6. Task-level signal: admission is localized to `budget-limit-rule` and `calendar-attendee`; this must be explicit in the Results narrative.
7. Validity and limitations: current Qwen rows pass pilot gates; Llama diagnostic/incomplete runs excluded.

## Figure/Table Mapping

- Main table: promoted Qwen results as clean success, one-shot unsafe, memory-path signal, delayed outcome, and execution failure.
- Task-level table: S1 has 3/6 PAR on `budget-limit-rule` and 3/6 PAR on `calendar-attendee`; inactive tasks are grouped.
- Figure 1: pipeline and memory write/filter/read order.
- Figure 2: current-turn unsafe bars plus a single stateful-unsafe endpoint summary.
- Figure 3: S1 causal-chain funnel; highlights where admission/retrieval stops before unsafe planner action.
- Figure 4: task localization for the S1 admission signal.
- Figure 5: horizon diagnostic; shows admission/retrieval at every horizon and summarizes the absent unsafe endpoint once.

## Deadline Checklist

- Keep the 40 human labels in `data/audit/audit_template.jsonl`.
- Keep the official `neurips_2026.sty` file in `paper/manuscript/`; `paper/manuscript/main.tex` uses it directly.
- Keep `paper/manuscript/checklist.tex` completed; it is copied from the official NeurIPS template.
- Rerun `python scripts/make_audit.py && python scripts/make_audit_review.py && python scripts/make_paper_tables.py && python scripts/make_paper_figures.py && python scripts/export_release.py`.
- Rerun `python scripts/check_neurips_readiness.py`; a nonzero exit means at least one submission blocker remains.
- Treat current Table 1 as promoted pilot-valid Qwen evidence, but do not generalize beyond the single actor/backend pair.
- In the paper, state the current trace count as 324 episodes and the release trace count as 324.

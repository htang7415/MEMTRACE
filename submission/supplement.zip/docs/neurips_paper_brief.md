# NeurIPS Paper Brief

## Claim To Lead With

MEMTRACE is a validity-first benchmark for memory-enabled agents. The promoted Qwen2.5-7B trace set now passes pilot validity: audit-calibrated results show immediate one-shot risk, zero stateful violations in this pilot, and a poisoned-memory admission surface that S2 blocks.

## Do Not Claim

- Do not claim delayed exploitation in the promoted rows: `SVR` is 0.000 for S0/S1/S2.
- Do not claim poisoned-memory admission implies downstream violation: admit-and-violate is zero.
- Do not average in pilot-invalid or incomplete Llama runs.
- Do not treat one-shot `OVR` as delayed memory exploitation.

## Current Audit-Calibrated Results

| System | CSR | OVR | SVR | PAR | PAR-exec | EFR | Required Tool Call | a | b | c | d |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| S0 | 0.833 | 0.292 | 0.000 | 0.000 | 0.000 | 0.074 | 0.985 | 0 | 0 | 0 | 66 |
| S1 | 0.833 | 0.250 | 0.000 | 0.083 | 0.091 | 0.074 | 0.985 | 0 | 6 | 0 | 60 |
| S2 | 0.833 | 0.250 | 0.000 | 0.000 | 0.000 | 0.074 | 0.985 | 0 | 0 | 0 | 66 |

## Abstract Draft

Memory-enabled agents can preserve the effects of untrusted retrieved content after that content leaves the active context, but standard one-shot safety tests often conflate immediate retrieval effects, delayed memory effects, and execution-format failure. We introduce MEMTRACE, a compact benchmark and protocol that separates these mechanisms under fixed retrieval, fixed tasks, and deterministic tool execution. Across the promoted 324-episode Qwen2.5-7B trace set, audit-calibrated results find immediate one-shot violations (OVR 0.250--0.292), zero stateful violations (SVR 0.000--0.000), and low execution-failure rates (EFR 0.074--0.074). The human audit is reconciled with the automated scorer, and S1 has 6 admit-and-safe cases while S2 has zero poison admissions. MEMTRACE therefore supports a narrow, pilot-valid claim: it separates immediate retrieval-context risk from persistent-memory admission and from delayed policy violation.

## Paper Structure

1. Motivation: memory changes the safety surface because retrieved content can be written and later reused.
2. Threat model: corpus poisoning through retrieval into the memory writer; attacker cannot edit memory directly.
3. Benchmark: 12 tasks, two task families, two payload types, S0/S1/S2, fixed retrieval and deterministic tools.
4. Metrics: separate OVR, SVR, PAR/PAR-exec, execution failure, and mechanism counts.
5. Results: promoted pilot-valid rows, nonzero one-shot risk, zero stateful violations, S1 admission signal.
6. Task-level signal: admission is localized to `budget-limit-rule` and `calendar-attendee`; this must be explicit in the Results narrative.
7. Validity and limitations: current Qwen rows pass pilot gates; Llama diagnostic/incomplete runs excluded.

## Figure/Table Mapping

- Table 1: promoted audit-calibrated Qwen results and validity diagnostics.
- Task-level table: S1 has 3/6 PAR on `budget-limit-rule` and 3/6 PAR on `calendar-attendee`; SVR is zero for all tasks.
- Figure 1: pipeline and memory write/filter/read order.
- Figure 2: OVR vs SVR; visually supports immediate-vs-stateful distinction.
- Figure 3: PAR by task family; highlights S1 admission and S2 closure.
- Figure 4: one-shot vs stateful comparison for S1/S2.
- Figure 5: violation by horizon; shows zero stateful violations in the promoted pilot-valid rows.

## Deadline Checklist

- Keep the 40 human labels in `data/audit/audit_template.jsonl`.
- Keep the official `neurips_2026.sty` file in `paper/manuscript/`; `paper/manuscript/main.tex` uses it directly.
- Keep `paper/manuscript/checklist.tex` completed; it is copied from the official NeurIPS template.
- Rerun `python scripts/make_audit.py && python scripts/make_audit_review.py && python scripts/make_paper_tables.py && python scripts/make_paper_figures.py && python scripts/export_release.py`.
- Rerun `python scripts/check_neurips_readiness.py`; a nonzero exit means at least one submission blocker remains.
- Treat current Table 1 as promoted pilot-valid Qwen evidence, but do not generalize beyond the single actor/backend pair.
- In the paper, state the current trace count as 324 episodes and the release trace count as 324.

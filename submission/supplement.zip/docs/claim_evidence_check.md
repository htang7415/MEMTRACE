# Claim-Evidence Check

- overall: PASS
- passing checks: 8/8

| Check | Status | Detail |
| --- | --- | --- |
| episode count | PASS | found `324-episode` |
| OVR range | PASS | found `OVR 0.250--0.292` |
| SVR range | PASS | found `SVR 0.000--0.000` |
| EFR range | PASS | found `EFR 0.074--0.074` |
| audit agreement | PASS | found `40/40 agreement` |
| pilot framing | PASS | metrics are pilot-valid |
| mechanism claims | PASS | mechanism claims match counts |
| failure attribution claims | PASS | memory-mediated unsafe count is zero |
